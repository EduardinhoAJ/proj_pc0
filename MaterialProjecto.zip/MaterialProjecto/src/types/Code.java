package types;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Code implements Cloneable {
    private final List<Colour> code;

 
    public Code(List<? extends Colour> code) {
        this.code = new ArrayList<>(code);
    }

   
    public List<Colour> getCode() {
        return new ArrayList<>(code); 
    }

  
    public int getLength() {
        return code.size(); 
    }

   
    public int[] howManyCorrect(Code other) {
    	
        int correctPosition = 0;
        int correctColour = 0;
        
        List<Boolean> checkedThis = new ArrayList<>(Collections.nCopies(this.getLength(), false));
        List<Boolean> checkedOther = new ArrayList<>(Collections.nCopies(other.getLength(), false));

      
        for (int i = 0; i < this.getLength(); i++) {
            if (i < other.getLength() && this.code.get(i).equals(other.getCode().get(i))) {
                correctPosition++;
                checkedThis.set(i, true); 
                checkedOther.set(i, true); 
            }
        }

        for (int i = 0; i < this.getLength(); i++) {
            if (!checkedThis.get(i)) { // Se ainda não foi verificado
                for (int j = 0; j < other.getLength(); j++) {
                    if (!checkedOther.get(j) && this.code.get(i).equals(other.getCode().get(j))) {
                        correctColour++;
                        checkedOther.set(j, true); // Marca a cor na outra posição como verificada
                        break; // Para não contar a mesma cor várias vezes
                    }
                }
            }
        }

        return new int[] { correctPosition, correctColour 
        		
         };
        
       }

 
   
    public String toString() {
        return code.toString(); // Usa o método toString da lista
    }

   
    protected Code clone() throws CloneNotSupportedException {
        return new Code(this.getCode()); // Retorna uma nova instância do código
    }

   
    public boolean equals(Object obj) {
        if (this == obj) return true; // Verifica referência
        if (!(obj instanceof Code)) return false; // Verifica tipo
        Code other = (Code) obj;
        return this.code.equals(other.getCode()); 
    }
}
