package types;

import java.util.List;
import java.util.Random;

public class BullsAndCows extends AbstractMastermindGame {
    private int score;
    public BullsAndCows(int seed, int size, Colour[] colours) {
        super(seed, size, colours);
        this.score = 0;
    }

    @Override
    public int score() {
        return score;
    }

    @Override
    public boolean updateScore() {
        if (isRoundFinished()) {
            score += 2000; // Adiciona 2000 pontos ao score
            return true;
        }
        return false;
    }

    @Override
    public boolean isRoundFinished() {
        // A rodada é considerada terminada se o número de tentativas for igual ao tamanho do código
        return getAttemptCount() >= size; // Assume que o tamanho do código é o limite de tentativas
    }

    @Override
    public Colour hint() {
        // Atualiza o score para metade do valor atual
        score /= 2;

        // Lógica para fornecer uma dica:
        // Aqui, vamos retornar uma cor aleatória do código secreto
        List<Colour> secretColours = getSecretCode().getCode();
        Random random = new Random();
        return secretColours.get(random.nextInt(secretColours.size()));
    }

    @Override
    public void addAttempt(Code attempt) {
        super.addAttempt(attempt);
    }
    @Override
    public Code bestTrial() {
        Code bestCode = null;
        int bestA = -1;
        int bestB = -1;

        for (Code attempt : getAttempts()) {
            // Supondo que você tenha um método que calcula a e b
            int a = calculateBulls(attempt);
            int b = calculateCows(attempt);

            // Verifica se encontramos um novo melhor código
            if (a > bestA || (a == bestA && b > bestB) || (a == bestA && b == bestB && (bestCode == null || attempt.compareTo(bestCode) < 0))) {
                bestCode = attempt;
                bestA = a;
                bestB = b;
            }
        }

        return bestCode; // Retorna o código com a melhor pontuação
    }

    private int calculateBulls(Code attempt) {
        // Implementação para calcular o número de bulls (a)
        return 0; // Exemplo
    }

    private int calculateCows(Code attempt) {
        // Implementação para calcular o número de cows (b)
        return 0; // Exemplo
    }

    

    // Método para reiniciar a contagem de tentativas se necessário
    public void resetRoundAttempts() {
    }

    // Método para verificar o resultado da tentativa
    public int[] checkAttempt(Code attempt) {
        return getSecretCode().howManyCorrect(attempt);
    }
}