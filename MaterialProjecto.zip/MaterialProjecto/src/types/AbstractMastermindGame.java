package types;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class AbstractMastermindGame implements MastermingGame {
	private final int seed; 
    protected final int size; 
    private final Colour[] colours; 
    private final List<Code> attempts; 
    private final Code secretCode; 
    private boolean isSecretRevealed; 

    public AbstractMastermindGame(int seed, int size, Colour[] colours) {
        this.seed = seed;
        this.size = size;
        this.colours = colours;
        this.attempts = new ArrayList<>();
        this.isSecretRevealed = false;

        this.secretCode = generateSecretCode();
    }

  
    public void addAttempt(Code attempt) {
        attempts.add(attempt);
    }
    
 // Método para obter as tentativas
    public List<Code> getAttempts() {
        return attempts; // Retorna a lista de tentativas
    }

 
    public Code getSecretCode() {
        return secretCode;
    }

 
    public void revealSecret() {
        isSecretRevealed = true;
    }

    
    public boolean isSecretRevealed() {
        return isSecretRevealed;
    }

  
    public int getAttemptCount() {
        return attempts.size();
    }
    protected abstract Code generateSecretCode(); // Método abstrato para gerar o código secreto
    

  
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Score: ").append(score()).append("\n");
        sb.append("Attempts: ").append(getAttemptCount()).append("\n");
        sb.append("Secret Code: ");
        if (isSecretRevealed) {
            sb.append(secretCode);
        } else {
            sb.append("?".repeat(size));
        }
        sb.append("\n");

        sb.append("Last 10 Attempts:\n");
        int start = Math.max(0, attempts.size() - 10);
        for (int i = start; i < attempts.size(); i++) {
            sb.append(attempts.get(i)).append("\n");
        }

        return sb.toString();
    }

    
    public abstract int score(); 
    public abstract boolean isRoundFinished(); 
    public abstract boolean updateScore(); 
}
