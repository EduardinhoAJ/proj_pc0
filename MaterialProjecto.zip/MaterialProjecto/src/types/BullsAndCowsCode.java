package types;

import java.util.List;

public class BullsAndCowsCode extends Code {

    public BullsAndCowsCode(List<BinaryColour> code) {
        super(code); 
    }

    
    public int[] howManyCorrect(Code other) {
       
        if (!(other instanceof BullsAndCowsCode)) {
            throw new IllegalArgumentException("Expected a BullsAndCowsCode instance.");
        }

        int blackPins = 0; 
        int whitePins = 0; 
        
        
        List<Colour> otherCode = other.getCode();
        
       
        boolean[] checkedThis = new boolean[this.getLength()];
        boolean[] checkedOther = new boolean[otherCode.size()];

       
        for (int i = 0; i < this.getLength(); i++) {
            if (i < otherCode.size() && this.getCode().get(i).equals(otherCode.get(i))) {
                blackPins++;
                checkedThis[i] = true; 
                checkedOther[i] = true; 
            }
        }

        
        for (int i = 0; i < this.getLength(); i++) {
            if (!checkedThis[i]) { 
                for (int j = 0; j < otherCode.size(); j++) {
                    if (!checkedOther[j] && this.getCode().get(i).equals(otherCode.get(j))) {
                        whitePins++;
                        checkedOther[j] = true; 
                        break; 
                    }
                }
            }
        }

        return new int[] { blackPins, whitePins }; 
    }
}
