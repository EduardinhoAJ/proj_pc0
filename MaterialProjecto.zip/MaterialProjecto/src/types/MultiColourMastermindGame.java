package types;

public class MultiColourMastermindGame extends AbstractMastermindGame {

    private int score; // Pontuação atual
    private boolean roundFinished; // Indica se a rodada está terminada
    private int hintsUsed; // Contador de ajudas usadas na rodada
    private int attempts; // Contador de tentativas feitas na rodada

    // Construtor que inicializa o jogo com a semente, tamanho e cores
    public MultiColourMastermindGame(int seed, int size, Colour[] colours) {
        super(seed, size, colours); // Chama o construtor da classe abstrata
        this.score = 0; // Inicializa o score com 0
        this.roundFinished = false; // Rodada começa como não finalizada
        this.hintsUsed = 0; // Nenhuma ajuda usada inicialmente
        this.attempts = 0; // Nenhuma tentativa feita inicialmente
    }

    // Retorna a pontuação atual do jogo
    @Override
    public int score() {
        return score;
    }

    // Atualiza o score com base nas regras e retorna se foi atualizado com sucesso
    @Override
    public boolean updateScore() {
        if (!roundFinished) {
            return false; // Não atualiza se a rodada não terminou
        }

        int baseScore = 0;

        // Define o valor base do score com base no número de tentativas
        if (attempts <= 2) {
            baseScore = 100;
        } else if (attempts <= 5) {
            baseScore = 50;
        } else {
            baseScore = 20;
        }

        // Divide o valor base pelo número de ajudas usadas + 1
        score += baseScore / (hintsUsed + 1);

        return true;
    }

    // Retorna se a rodada está terminada
    @Override
    public boolean isRoundFinished() {
        return roundFinished;
    }

    // Fornece uma dica e incrementa o contador de ajudas
    @Override
    public Colour hint() {
        Colour hintColour = super.hint(); // Obtém a dica da classe abstrata
        hintsUsed++; // Incrementa o contador de ajudas usadas
        return hintColour;
    }

    // Métodos auxiliares para controlar o estado do jogo

    // Define que a rodada foi finalizada
    public void setRoundFinished(boolean finished) {
        this.roundFinished = finished;
    }

    // Incrementa o número de tentativas feitas
    public void incrementAttempts() {
        this.attempts++;
    }

    // Reinicia os dados da rodada, preparando para uma nova rodada
    public void resetRound() {
        this.roundFinished = false;
        this.hintsUsed = 0;
        this.attempts = 0;
    }

	@Override
	public void play(Code trial) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startNewRound() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Code bestTrial() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getNumberOfTrials() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean wasSecretRevealed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected Code generateSecretCode() {
		// TODO Auto-generated method stub
		return null;
	}
}
