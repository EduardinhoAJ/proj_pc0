package TestesProjeto.main;

import types.Colour;
import types.MultiColourMastermindGame;

public class Main {
    public static void main(String[] args) {
        // Configuração inicial do jogo
        int seed = 12345; // Semente para gerar códigos consistentes
        int size = 4; // Tamanho do código a ser adivinhado
        Colour[] colours = {Colour.RED, Colour.Pink, Colour.Orange, Colour.Blue}; // Conjunto de cores disponíveis

        // Criação de um jogo Mastermind MultiColour
        MultiColourMastermindGame game = new MultiColourMastermindGame(seed, size, colours);

        // Exercitando funcionalidades
        System.out.println("Iniciando o jogo MultiColour Mastermind!");
        System.out.println("Código gerado com sucesso. Tente adivinhar!");

        // Simulando uma rodada
        game.incrementAttempts(); // Primeira tentativa
        System.out.println("Tentativa 1 realizada.");

        // Solicitando uma dica
        Colour hint = game.hint();
        System.out.println("Dica fornecida: " + hint);
        System.out.println("Número de ajudas usadas: 1");

        // Simulando mais tentativas
        game.incrementAttempts();
        game.incrementAttempts();
        System.out.println("Tentativas realizadas: " + game.score() + " tentativas.");

        // Finalizando a rodada
        game.setRoundFinished(true);

        // Atualizando o score após a rodada
        boolean scoreUpdated = game.updateScore();
        if (scoreUpdated) {
            System.out.println("Pontuação atualizada com sucesso!");
        }
        System.out.println("Pontuação final da rodada: " + game.score());

        // Reiniciando para uma nova rodada
        game.resetRound();
        System.out.println("Nova rodada iniciada. Boa sorte!");

        // Exercício adicional: testar diferentes cenários (mais tentativas, mais dicas)
        // e imprimir os resultados relevantes.
    }
}
