package types;

import java.util.Random;

public abstract class BullsAndCows extends AbstractMastermindGame {
    private int score;
    private boolean roundFinished;
    private Colour[] colours;
    private int size;

    // Construtor
    public BullsAndCows(int seed, int size, Colour[] colours) {
        super(seed,size, colours); // Chama o construtor da classe abstrata
        this.size = size;
        this.colours = colours;
        this.score = 0; // Inicializa o score
        this.roundFinished = false; // Inicializa o estado da ronda
    }

    // Método para obter o score atual
    @Override
    public int score() {
        return this.score;
    }

    // Método para atualizar o score
    @Override
    public boolean updateScore() {
        this.score += 2000; // Adiciona 2000 pontos ao score
        return true; // Retorna verdadeiro indicando que a atualização foi bem-sucedida
    }

    // Método para verificar se a ronda está terminada
    @Override
    public boolean isRoundFinished() {
        return this.roundFinished; // Retorna o estado da ronda
    }

    // Método para dar uma dica e atualizar o score
    @Override
    public Colour hint() {
        // Atualiza o score para metade do valor atual
        this.score /= 2;
        // Lógica para fornecer uma dica (exemplo simples)
        Random random = new Random();
        return colours[random.nextInt(colours.length)]; // Retorna uma cor aleatória como dica
    }

    // Método para terminar a ronda (pode ser chamado em outros métodos)
    public void finishRound() {
        this.roundFinished = true; // Marca a ronda como terminada
    }

    // Outros métodos relevantes para a lógica do jogo podem ser adicionados aqui
}
