package types;

import java.util.List;

public class BullsAndCowsCode extends Code {

   
    public BullsAndCowsCode(List<BinaryColour> code) {
        super(code); // Chama o construtor da classe pai (Code)
    }

    public int[] howManyCorrect(Code other) {
        
    	int a = 0; // Pinos pretos (cor e posição corretas)
        int b = 0; // Pinos brancos (cor correta, mas posição errada)
       
        
        boolean[] checkedThis = new boolean[this.getLength()];
        boolean[] checkedOther = new boolean[other.getLength()];

       
        for (int i = 0; i < this.getLength(); i++) {
            if (this.getCode().get(i).equals(other.getCode().get(i))) {
                a++; // Incrementa o número de pinos pretos
                checkedThis[i] = true; // Marca como verificado
                checkedOther[i] = true; // Marca como verificado
            }
        }

        
        for (int i = 0; i < this.getLength(); i++) {
            if (!checkedThis[i]) { // Se não foi verificado
                for (int j = 0; j < other.getLength(); j++) {
                    if (!checkedOther[j] && this.getCode().get(i).equals(other.getCode().get(j))) {
                        b++; // Incrementa o número de pinos brancos
                        checkedOther[j] = true; // Marca como verificado
                        break; // Para evitar contar a mesma cor mais de uma vez
                    }
                }
            }
        }

        return new int[]{a, b}; // Retorna o resultado como um vetor com 'a' e 'b'
    }