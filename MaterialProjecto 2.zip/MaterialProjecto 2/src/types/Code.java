package types;

import java.util.ArrayList;
import java.util.List;

public class Code implements Cloneable {
    
    private List<Colour> code; // Lista que armazena as cores do código

    public Code(List<? extends Colour> code) {
        this.code = new ArrayList<>(code); // Cria uma nova lista a partir da lista fornecida
    }

    public List<Colour> getCode() {
        return new ArrayList<>(this.code); // Retorna uma cópia da lista de cores
    }

    public int getLength() {
        return this.code.size(); // Retorna o tamanho da lista de cores
    }

    public int[] howManyCorrect(Code other) {
        int a = 0; // Pinos pretos (cor e posição corretas)
        int b = 0; // Pinos brancos (cor correta, mas posição errada)
        boolean[] checkedThis = new boolean[this.getLength()];
        boolean[] checkedOther = new boolean[other.getLength()];

        // Primeiro, contamos os pinos pretos (posição e cor corretas)
        for (int i = 0; i < this.getLength(); i++) {
            if (this.getCode().get(i).equals(other.getCode().get(i))) {
                a++; // Incrementa o número de pinos pretos
                checkedThis[i] = true; // Marca como verificado
                checkedOther[i] = true; // Marca como verificado
            }
        }

        // Depois, contamos os pinos brancos (cor correta, mas posição errada)
        for (int i = 0; i < this.getLength(); i++) {
            if (!checkedThis[i]) { // Se não foi verificado
                for (int j = 0; j < other.getLength(); j++) {
                    if (!checkedOther[j] && this.getCode().get(i).equals(other.getCode().get(j))) {
                        b++; // Incrementa o número de pinos brancos
                        checkedOther[j] = true; // Marca como verificado
                        break; // Para evitar contar a mesma cor mais de uma vez
                    }
                }
            }
        }

        return new int[]{a, b}; // Retorna o resultado como um vetor com 'a' e 'b'
    }


    public String toString() {
        return this.code.toString(); // Utiliza o método toString da lista
    }

    public Code clone() {
        try {
            Code cloned = (Code) super.clone();
            cloned.code = new ArrayList<>(this.code); // Clona a lista de cores
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(); // Não deve acontecer
        }
    }
  
    public boolean equals(Object obj) {
       
        if (this == obj) return true; 
        
        // Verifica se o objeto é uma instância de Code
        if (!(obj instanceof Code)) return false; 
        
        // Faz o cast do objeto para Code
        Code other = (Code) obj; 
        
        // Compara as listas de cores
        return this.code.equals(other.getCode()); 
    }
}

