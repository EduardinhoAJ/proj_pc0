package types;

import java.util.Random;

public class MultiColourMastermindGame extends AbstractMastermindGame {

    private int score; // Pontuação atual do jogo
    private boolean roundFinished; // Estado da rodada
    private int hintsUsed; // Número de ajudas (hints) utilizadas na rodada
    private int attempts; // Número de tentativas feitas na rodada

    // Construtor que inicializa o jogo com a semente, tamanho e cores
    public MultiColourMastermindGame(int seed, int size, Colour[] colours) {
        super(seed, size, colours);
        this.score = 0; // Inicializa o score em 0
        this.roundFinished = false; // Inicializa o estado da rodada como não terminada
        this.hintsUsed = 0; // Nenhuma ajuda usada inicialmente
        this.attempts = 0; // Nenhuma tentativa feita inicialmente
    }

    // Método que devolve o score atual
    @Override
    public int score() {
        return score;
    }

    // Método que atualiza o score após o término de uma rodada
    @Override
    public boolean updateScore() {
        if (!roundFinished) {
            return false; // Não faz nada se a rodada não terminou
        }

        int baseScore = 0;

        // Determina a pontuação base de acordo com o número de tentativas
        if (attempts <= 2) {
            baseScore = 100;
        } else if (attempts <= 5) {
            baseScore = 50;
        } else {
            baseScore = 20;
        }

        // Ajusta o score com base no número de ajudas usadas
        score += baseScore / (hintsUsed + 1);
        return true;
    }

    // Método que verifica se a rodada está terminada
    @Override
    public boolean isRoundFinished() {
        return roundFinished;
    }

    // Método que reimplementa o `hint` e contabiliza o número de ajudas
    @Override
    public Colour hint() {
        // Obtém a dica da implementação da classe abstrata
        Colour hintColour = super.hint();
        // Incrementa o contador de ajudas usadas
        hintsUsed++;
        return hintColour;
    }

    // Métodos auxiliares para gerenciar o estado da rodada

    // Define que a rodada foi finalizada
    public void setRoundFinished(boolean finished) {
        this.roundFinished = finished;
    }

    // Incrementa o número de tentativas feitas
    public void incrementAttempts() {
        this.attempts++;
    }

    // Reinicia o estado de uma nova rodada
    public void resetRound() {
        this.roundFinished = false;
        this.hintsUsed = 0;
        this.attempts = 0;
    }
}
